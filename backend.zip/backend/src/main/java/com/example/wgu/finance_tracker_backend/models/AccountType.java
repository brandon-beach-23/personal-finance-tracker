package com.example.wgu.finance_tracker_backend.models;

public enum AccountType {
    CHECKING,
    SAVINGS
}

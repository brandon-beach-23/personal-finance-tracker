package com.example.wgu.finance_tracker_backend.models;

public enum TransactionType {
    DEBIT,
    CREDIT
}
